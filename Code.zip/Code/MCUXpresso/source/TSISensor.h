#include "MKL46Z4.h"

void TSI_Init(void);

int TSI_Scan(void);

void TSI0_IRQHandler(void);
