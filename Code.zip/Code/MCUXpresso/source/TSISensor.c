#include <MKL46Z4.h>
#include <TSISensor.h>
#include "LCD.h"

void TSI_Init(void){

	SIM->SCGC5 |= SIM_SCGC5_TSI_MASK;   //enable clock

	TSI0->GENCS = TSI_GENCS_OUTRGF_MASK // clear out of range flag

							|	TSI_GENCS_MODE(0)			// set capacitive mode (0000 is non-noise detection mode)
							|	TSI_GENCS_REFCHRG(0)	// oscillator charge and discharge current value (000 - 500 nA)
							|	TSI_GENCS_DVOLT(0)		// sets the oscillator's voltage rails (00 - DV = 1.03 V; VP = 1.33 V; Vm = 0.30 V)
							|	TSI_GENCS_EXTCHRG(0)  // sets the electrode oscillator charge and discharge current value (000 - 500 nA)
							|	TSI_GENCS_PS(0)				// sets the prescaler of the output of electrode oscillator (00 - Electrode Oscillator Frequency divided by 1)
							|	TSI_GENCS_NSCN(31)	  // sets the scan number for each electrode (scans = NSCN + 1) 32 is max amount of scans

							|	TSI_GENCS_TSIEN_MASK	// enables TSI
							//| TSI_GENCS_STPE_MASK   // Enables TSI in low power mode
							| TSI_GENCS_EOSF_MASK;
}

int TSI_Scan(void){
	int data;
	TSI0->DATA = TSI_DATA_TSICH(10)		// enables channel 10 which reads data from left to right as low to high
						 | TSI_DATA_SWTS_MASK;	// starts scan
	data = (TSI0->DATA & 0xFFFF) - 625; // reading the bits stored in TSI0_DATA_TSICNT
															 // this number at the end is subtracted so that the left end is about equal to 0
		TSI0->GENCS |= TSI_GENCS_EOSF_MASK ; // Reset end of scan flag
	return data;
}
